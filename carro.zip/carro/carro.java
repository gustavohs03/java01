public class carro {
    public static void main(String[] args) {
        String marca;
        String modelo;
        int ano;
        String cor;
        double velocidade;
        boolean ligado;

    }

}
